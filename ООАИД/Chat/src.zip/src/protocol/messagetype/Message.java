package protocol.messagetype;

import java.io.Serializable;

/**
 * Created by Yana on 03.12.15.
 */
public interface Message extends Serializable {
}
