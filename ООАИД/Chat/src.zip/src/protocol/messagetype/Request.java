package protocol.messagetype;

/**
 * Created by Yana on 03.12.15.
 */
public interface Request {
}
