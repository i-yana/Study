package protocol.requests;

import protocol.messagetype.Message;
import protocol.messagetype.Request;

/**
 * Created by Yana on 05.07.15.
 */
public class LogoutMSG implements Request, Message {
}
