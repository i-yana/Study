package client;

import client.controller.AuthorizationController;

/**
 * Created by Yana on 16.12.15.
 */
public class Client {

    public static void main(String[] args) {
        AuthorizationController controller = new AuthorizationController();
    }

}
